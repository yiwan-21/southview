<section id="logout">
        <br><br><br><br>
        <div class="container-fluid-lg-12" >
            <div class="row justify-content-center" >
                <div class="col-lg-9"></div>
                <div class="col-lg-2 justify-content-end d-flex align-items-end">
                <div class="col-lg-1"></div>                              
                <a href="javascript:Alert();" class="logoutbtn">LOGOUT</a>
            </div>          
                </div>
            </div>
</section>



