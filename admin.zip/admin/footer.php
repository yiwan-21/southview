
<footer class="container-fluid container-footer text-center text-lg-center" style="padding:0;margin:0">
      <div class="footer row d-flex align-items-center">
  
      <!-- copyright text -->
      <div class="col-lg-12 my-1 text-center text-lg-center">
        <i>Copyright © 2022 SV Community</i>
      </div>
      </div>
</footer>







